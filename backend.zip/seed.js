const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const User = require('../models/User');
const Crop = require('../models/Crop');
const Field = require('../models/Field');
const Order = require('../models/Order');

const seed = async () => {
  await mongoose.connect(process.env.MONGO_URI);
  console.log('Connected — seeding...');

  await User.deleteMany(); await Crop.deleteMany();
  await Field.deleteMany(); await Order.deleteMany();

  // Users
  const farmer = await User.create({ name:'Harishh I', email:'harishh@farm.com', password:'farmer123', role:'farmer', phone:'9876543210', farmName:'Harishh Farms', farmSize:4.2, location:{city:'Erode',state:'Tamil Nadu'}, verified:true, rating:4.8, wallet:38250 });
  const buyer1  = await User.create({ name:'Rajesh Kumar',  email:'rajesh@buyer.com',  password:'buyer123', role:'buyer', location:{city:'Chennai',state:'Tamil Nadu'} });
  const buyer2  = await User.create({ name:'Anitha Devi',   email:'anitha@buyer.com',  password:'buyer123', role:'buyer', location:{city:'Coimbatore',state:'Tamil Nadu'} });
  const admin   = await User.create({ name:'Admin User',    email:'admin@farm.com',    password:'admin123', role:'admin' });

  // Fields
  const fieldA = await Field.create({ farmer:farmer._id, name:'North Field A', size:1.2, emoji:'🍅', color:'#c4e0a0', soilType:'Loamy', currentCrop:'Tomato', irrigationType:'Drip', sensors:{moisture:72,ph:6.4,nitrogen:68,temperature:28}, healthStatus:'Good' });
  const fieldB = await Field.create({ farmer:farmer._id, name:'South Field B', size:0.8, emoji:'🥦', color:'#b8d880', soilType:'Sandy', currentCrop:'Broccoli', irrigationType:'Sprinkler', sensors:{moisture:58,ph:6.1,nitrogen:82,temperature:26}, healthStatus:'Excellent' });
  const fieldC = await Field.create({ farmer:farmer._id, name:'East Field C',  size:1.4, emoji:'🌾', color:'#d4c870', soilType:'Clay',  currentCrop:'Turmeric', irrigationType:'Flood', sensors:{moisture:45,ph:5.8,nitrogen:55,temperature:31}, healthStatus:'Needs Attention' });

  // Crops
  const crops = await Crop.insertMany([
    { farmer:farmer._id, emoji:'🍅', name:'Tomato',   variety:'Hybrid', category:'Vegetables', quantity:850, sold:320, price:22, fieldName:'North Field A', tags:['Organic','Seasonal'], growth:75, rating:4.7 },
    { farmer:farmer._id, emoji:'🥦', name:'Broccoli', variety:'Country',category:'Vegetables', quantity:420, sold:180, price:55, fieldName:'South Field B', tags:['Organic','Premium'], growth:60, rating:4.8 },
    { farmer:farmer._id, emoji:'🌾', name:'Turmeric', variety:'Erode Special',category:'Spices', quantity:600, sold:250, price:90, fieldName:'East Field C', tags:['Organic','Premium'], growth:40, rating:4.9 },
    { farmer:farmer._id, emoji:'🥕', name:'Carrot',   variety:'Nantes', category:'Vegetables', quantity:700, sold:500, price:18, fieldName:'North Field A', tags:['Organic'], growth:85, rating:4.6 },
    { farmer:farmer._id, emoji:'🌽', name:'Corn',     variety:'Sweet',  category:'Vegetables', quantity:1200,sold:700, price:15, fieldName:'South Field B', tags:['Seasonal'], growth:90, rating:4.5 },
    { farmer:farmer._id, emoji:'🧅', name:'Onion',    variety:'Red Medium',category:'Vegetables',quantity:2000,sold:800,price:28, fieldName:'East Field C', tags:['Organic'], growth:55, rating:4.7 },
  ]);

  // Orders
  await Order.insertMany([
    { buyer:buyer1._id, farmer:farmer._id, crop:crops[0]._id, cropName:'Tomato', quantity:50, pricePerKg:22, totalAmount:1100, status:'Pending', paymentStatus:'Pending', deliveryAddress:{city:'Chennai',state:'Tamil Nadu'}, tracking:[{status:'Pending',message:'Order placed'}] },
    { buyer:buyer2._id, farmer:farmer._id, crop:crops[1]._id, cropName:'Broccoli',quantity:20,pricePerKg:55,totalAmount:1100,status:'In Transit',paymentStatus:'Pending',deliveryAddress:{city:'Coimbatore',state:'Tamil Nadu'},tracking:[{status:'Pending',message:'Order placed'},{status:'In Transit',message:'Dispatched'}] },
    { buyer:buyer1._id, farmer:farmer._id, crop:crops[3]._id, cropName:'Carrot', quantity:80, pricePerKg:18, totalAmount:1440, status:'Delivered', paymentStatus:'Paid', deliveryAddress:{city:'Ooty',state:'Tamil Nadu'}, tracking:[{status:'Delivered',message:'Delivered'}] },
  ]);

  console.log('✅ Seed complete!');
  console.log('Farmer login:  harishh@farm.com / farmer123');
  console.log('Buyer login:   rajesh@buyer.com / buyer123');
  console.log('Admin login:   admin@farm.com / admin123');
  process.exit(0);
};

seed().catch(err => { console.error(err); process.exit(1); });
