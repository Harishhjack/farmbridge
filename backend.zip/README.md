# 🌾 FarmBridge — Farm to Table Platform

A full-stack MERN application connecting farmers directly with buyers, eliminating middlemen and ensuring fair prices.

## ✨ Features

| Module | Features |
|--------|----------|
| 🔐 Auth | JWT login, role-based (farmer / buyer / admin) |
| 🌱 Crop Management | List, edit, boost, review crops |
| 🛒 Marketplace | Search, filter, sort, cart, real-time prices |
| 📦 Orders | Place, dispatch, track, cancel orders |
| 💰 Wallet | Balance, withdraw, transaction history |
| 🗺️ Field Map | Add fields, sensor data (moisture, pH, N, temp) |
| 💬 Real-time Chat | Socket.io messaging between farmer & buyer |
| 📊 Analytics | Revenue, top buyers, seasonal trends |
| 🌤 Advisory | Weather forecast + crop advisory |
| 📣 Govt Schemes | Tamil Nadu + India schemes listing |

## 🛠 Tech Stack

**Backend:** Node.js · Express.js · MongoDB · Mongoose · Socket.io · JWT · Bcrypt  
**Frontend:** React.js · Axios · React Router · Recharts  
**Database:** MongoDB Atlas (free tier)  
**Deploy:** Render (backend) · Vercel (frontend)

## 🚀 Quick Start

### 1. Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/farmbridge.git
cd farmbridge
```

### 2. Backend setup
```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your MongoDB URI and JWT secret
npm run seed     # populate sample data
npm run dev      # start on http://localhost:5000
```

### 3. Frontend setup
```bash
cd ../frontend
npm install
npm start        # start on http://localhost:3000
```

## 🔑 API Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register farmer/buyer |
| POST | `/api/auth/login` | Login |
| GET  | `/api/auth/me` | Get current user |
| PUT  | `/api/auth/profile` | Update profile |

### Crops (Farmer)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/crops` | My crop listings |
| POST | `/api/crops` | List new crop |
| PUT  | `/api/crops/:id` | Update crop |
| DELETE | `/api/crops/:id` | Remove listing |
| POST | `/api/crops/:id/review` | Add buyer review |

### Marketplace
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/market` | Browse all produce |
| GET | `/api/market/prices` | Live price ticker |
| GET | `/api/market/:id` | Single listing detail |

### Orders
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/orders` | My orders |
| POST | `/api/orders` | Place order |
| PUT | `/api/orders/:id/status` | Update status |
| PUT | `/api/orders/:id/cancel` | Cancel order |

### Wallet
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/wallet` | Balance + transactions |
| POST | `/api/wallet/withdraw` | Withdraw to bank |

### Others
- `GET /api/fields` · `POST /api/fields` · `PUT /api/fields/:id/sensors`
- `GET /api/analytics` — revenue, top crops, top buyers
- `GET /api/advisory` — weather + crop advisory
- `GET /api/schemes` — government schemes
- `GET /api/chat/:userId` · `POST /api/chat/:userId`

## 📁 Project Structure

```
farmbridge/
├── backend/
│   ├── config/          # DB connection
│   ├── middleware/       # JWT auth
│   ├── models/          # Mongoose schemas
│   │   ├── User.js
│   │   ├── Crop.js
│   │   ├── Order.js
│   │   ├── Field.js
│   │   ├── Message.js
│   │   └── Wallet.js
│   ├── routes/          # Express routers
│   │   ├── auth.js
│   │   ├── crops.js
│   │   ├── market.js
│   │   ├── orders.js
│   │   ├── wallet.js
│   │   ├── fields.js
│   │   ├── chat.js
│   │   ├── analytics.js
│   │   ├── schemes.js
│   │   └── advisory.js
│   ├── utils/seed.js    # Sample data seeder
│   ├── server.js        # Entry point + Socket.io
│   └── .env.example
└── README.md
```

## 🌐 Deployment

### MongoDB Atlas (Free)
1. Create account at cloud.mongodb.com
2. Create free M0 cluster
3. Add connection string to `.env` as `MONGO_URI`

### Backend on Render (Free)
1. Connect GitHub repo at render.com
2. Set root directory: `backend`
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables from `.env`

### Frontend on Vercel (Free)
1. Connect GitHub repo at vercel.com
2. Set root directory: `frontend`
3. Add `REACT_APP_API_URL=https://your-render-url.onrender.com`

## 👤 Default Logins (after seeding)
| Role | Email | Password |
|------|-------|----------|
| Farmer | harishh@farm.com | farmer123 |
| Buyer | rajesh@buyer.com | buyer123 |
| Admin | admin@farm.com | admin123 |

## 👨‍💻 Developer
**Harishh I** · B.Sc CS · Nandha Arts & Science College, Erode
