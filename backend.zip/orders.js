const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const Crop = require('../models/Crop');
const User = require('../models/User');
const Transaction = require('../models/Wallet');
const { protect, authorize } = require('../middleware/auth');

// GET /api/orders
router.get('/', protect, async (req, res) => {
  try {
    const { status, role } = req.query;
    const filter = req.user.role === 'buyer' ? { buyer: req.user._id } : { farmer: req.user._id };
    if (status) filter.status = status;
    const orders = await Order.find(filter)
      .populate('buyer', 'name email phone')
      .populate('farmer', 'name farmName phone')
      .populate('crop', 'name emoji')
      .sort({ createdAt: -1 });
    res.json({ success: true, count: orders.length, data: orders });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// POST /api/orders — place order
router.post('/', protect, authorize('buyer','admin'), async (req, res) => {
  try {
    const { cropId, quantity, deliveryAddress, notes } = req.body;
    const crop = await Crop.findById(cropId).populate('farmer');
    if (!crop) return res.status(404).json({ success: false, message: 'Crop not found' });
    if (crop.quantity < quantity) return res.status(400).json({ success: false, message: 'Insufficient stock' });

    const totalAmount = crop.price * quantity;
    const order = await Order.create({
      buyer: req.user._id, farmer: crop.farmer._id, crop: crop._id,
      cropName: crop.name, quantity, pricePerKg: crop.price, totalAmount,
      deliveryAddress, notes,
      tracking: [{ status: 'Pending', message: 'Order placed successfully' }]
    });

    // Reduce stock
    crop.quantity -= quantity;
    crop.sold += quantity;
    await crop.save();

    // Notify farmer via socket
    req.io?.emit('new_order', { farmerId: crop.farmer._id, orderId: order._id, crop: crop.name, quantity });

    res.status(201).json({ success: true, data: order });
  } catch (err) { res.status(400).json({ success: false, message: err.message }); }
});

// PUT /api/orders/:id/status — update order status
router.put('/:id/status', protect, async (req, res) => {
  try {
    const { status, message } = req.body;
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });

    order.status = status;
    order.tracking.push({ status, message: message || `Order ${status}` });
    if (status === 'In Transit') order.dispatchedAt = new Date();
    if (status === 'Delivered') {
      order.deliveredAt = new Date();
      order.paymentStatus = 'Paid';
      // Credit farmer wallet
      const farmer = await User.findById(order.farmer);
      farmer.wallet += order.totalAmount;
      await farmer.save();
      await Transaction.create({ user: order.farmer, type: 'credit', amount: order.totalAmount, description: `Payment for Order #${order._id.toString().slice(-6)}`, orderId: order._id, balance: farmer.wallet });
    }
    await order.save();

    req.io?.emit('order_updated', { orderId: order._id, status });
    res.json({ success: true, data: order });
  } catch (err) { res.status(400).json({ success: false, message: err.message }); }
});

// PUT /api/orders/:id/cancel
router.put('/:id/cancel', protect, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ success: false, message: 'Not found' });
    if (order.status !== 'Pending') return res.status(400).json({ success: false, message: 'Can only cancel pending orders' });

    order.status = 'Cancelled';
    order.cancelReason = req.body.reason || '';
    order.tracking.push({ status: 'Cancelled', message: req.body.reason || 'Cancelled by user' });
    await order.save();

    // Restore stock
    await Crop.findByIdAndUpdate(order.crop, { $inc: { quantity: order.quantity, sold: -order.quantity } });
    res.json({ success: true, data: order });
  } catch (err) { res.status(400).json({ success: false, message: err.message }); }
});

module.exports = router;
