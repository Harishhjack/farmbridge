const express = require('express');
const router = express.Router();
const Crop = require('../models/Crop');
const User = require('../models/User');
const { protect, authorize } = require('../middleware/auth');

// GET /api/crops — my crops
router.get('/', protect, authorize('farmer','admin'), async (req, res) => {
  try {
    const crops = await Crop.find({ farmer: req.user._id }).sort({ createdAt: -1 });
    res.json({ success: true, count: crops.length, data: crops });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// POST /api/crops — list new crop
router.post('/', protect, authorize('farmer','admin'), async (req, res) => {
  try {
    req.body.farmer = req.user._id;
    const crop = await Crop.create(req.body);
    req.io?.emit('crop_listed', { farmerId: req.user._id, crop: crop.name });
    res.status(201).json({ success: true, data: crop });
  } catch (err) { res.status(400).json({ success: false, message: err.message }); }
});

// PUT /api/crops/:id
router.put('/:id', protect, authorize('farmer','admin'), async (req, res) => {
  try {
    const crop = await Crop.findOneAndUpdate({ _id: req.params.id, farmer: req.user._id }, req.body, { new: true, runValidators: true });
    if (!crop) return res.status(404).json({ success: false, message: 'Crop not found' });
    res.json({ success: true, data: crop });
  } catch (err) { res.status(400).json({ success: false, message: err.message }); }
});

// DELETE /api/crops/:id
router.delete('/:id', protect, authorize('farmer','admin'), async (req, res) => {
  try {
    await Crop.findOneAndDelete({ _id: req.params.id, farmer: req.user._id });
    res.json({ success: true, message: 'Crop removed from listings' });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// POST /api/crops/:id/review
router.post('/:id/review', protect, authorize('buyer'), async (req, res) => {
  try {
    const crop = await Crop.findById(req.params.id);
    if (!crop) return res.status(404).json({ success: false, message: 'Crop not found' });
    crop.reviews.push({ buyer: req.user._id, rating: req.body.rating, comment: req.body.comment });
    crop.rating = crop.reviews.reduce((a, r) => a + r.rating, 0) / crop.reviews.length;
    await crop.save();
    res.json({ success: true, data: crop });
  } catch (err) { res.status(400).json({ success: false, message: err.message }); }
});

module.exports = router;
