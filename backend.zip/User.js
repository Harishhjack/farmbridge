const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const UserSchema = new mongoose.Schema({
  name:        { type: String, required: true, trim: true },
  email:       { type: String, required: true, unique: true, lowercase: true },
  password:    { type: String, required: true, minlength: 6, select: false },
  role:        { type: String, enum: ['farmer','buyer','admin'], default: 'farmer' },
  phone:       { type: String, default: '' },
  location:    { city: String, state: String, pincode: String },
  farmName:    { type: String, default: '' },
  farmSize:    { type: Number, default: 0 },  // in acres
  verified:    { type: Boolean, default: false },
  rating:      { type: Number, default: 0, min: 0, max: 5 },
  totalOrders: { type: Number, default: 0 },
  wallet:      { type: Number, default: 0 },
  avatar:      { type: String, default: '' },
  isActive:    { type: Boolean, default: true },
}, { timestamps: true });

UserSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

UserSchema.methods.matchPassword = async function(pwd) {
  return await bcrypt.compare(pwd, this.password);
};

UserSchema.methods.getToken = function() {
  return jwt.sign({ id: this._id, role: this.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRE });
};

module.exports = mongoose.model('User', UserSchema);
