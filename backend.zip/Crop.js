const mongoose = require('mongoose');

const CropSchema = new mongoose.Schema({
  farmer:    { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  emoji:     { type: String, default: '🌾' },
  name:      { type: String, required: true, trim: true },
  variety:   { type: String, default: 'Standard' },
  category:  { type: String, enum: ['Vegetables','Fruits','Grains','Spices','Pulses','Other'], default: 'Vegetables' },
  quantity:  { type: Number, required: true, min: 1 },    // kg available
  sold:      { type: Number, default: 0 },
  price:     { type: Number, required: true, min: 0 },    // per kg
  field:     { type: mongoose.Schema.Types.ObjectId, ref: 'Field' },
  fieldName: { type: String, default: '' },
  tags:      [{ type: String, enum: ['Organic','Premium','Seasonal','Fresh','Bulk'] }],
  harvestDate: { type: Date },
  expiryDate:  { type: Date },
  growth:    { type: Number, default: 0, min: 0, max: 100 }, // %
  isListed:  { type: Boolean, default: true },
  images:    [String],
  rating:    { type: Number, default: 0, min: 0, max: 5 },
  reviews:   [{ buyer: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, rating: Number, comment: String, date: { type: Date, default: Date.now } }],
}, { timestamps: true });

CropSchema.index({ name: 'text', variety: 'text' });
module.exports = mongoose.model('Crop', CropSchema);
