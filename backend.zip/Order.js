const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
  buyer:       { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  farmer:      { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  crop:        { type: mongoose.Schema.Types.ObjectId, ref: 'Crop', required: true },
  cropName:    { type: String },
  quantity:    { type: Number, required: true, min: 1 },
  pricePerKg:  { type: Number, required: true },
  totalAmount: { type: Number, required: true },
  status:      { type: String, enum: ['Pending','Confirmed','In Transit','Delivered','Cancelled'], default: 'Pending' },
  paymentStatus: { type: String, enum: ['Pending','Paid','Refunded'], default: 'Pending' },
  deliveryAddress: { street: String, city: String, state: String, pincode: String },
  notes:       { type: String, default: '' },
  dispatchedAt: Date,
  deliveredAt:  Date,
  cancelReason: { type: String, default: '' },
  tracking:    [{ status: String, message: String, time: { type: Date, default: Date.now } }],
}, { timestamps: true });

module.exports = mongoose.model('Order', OrderSchema);
